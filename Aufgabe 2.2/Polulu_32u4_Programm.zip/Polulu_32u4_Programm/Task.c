#include <stdio.h>
#include "Task.h"

// Implementation of Task_init function
Task_Ret Task_init(Task* task, TaskWorkCallback workCallback, TaskState state, void* data) {
    if (task == 0 || workCallback == 0) {
        return TASK_ERROR;
    }

    task->workCallback = workCallback;
    task->state = state;
    task->data = data;


    switch (state) {
    case WAIT:
        printf("Entering WAIT state\n");
        Wait_NotifyStateHandler();
        // Insert more logic for the WAIT state here or function calls
        break;


    case CALIBRATION:
        printf("Entering CALIBRATION state\n");
        Calibration_Process();
        // Insert more logic for the calibration status here or function calls
        break;


    case MODE_SWITCH:
        printf("Entering MODE_SWITCH state\n");
        ModeSwitch_SwitchToNextParameterSet();
        // Insert more logic for the MODE_SWITCH state here or function calls
        break;


    case START_RACE:
        printf("Entering START_RACE state\n");
        StartRace_Process();
        // Insert more logic for the START_RACE state here or function calls
        break;


    case RUN_RACE:
        printf("Entering RUN_RACE state\n");
        RunRace_Process();
        // Insert more logic for the RUN_RACE state here or function calls
        break;


    case RACE_DONE:
        printf("Entering RACE_DONE state\n");
        RaceDone_Process();
        // Insert more logic for the RACE_DONE state here or function calls
        break;

    default:
        printf("Unknown state\n");
        break;

    return TASK_SUCCESS;
}
