#ifndef TASK_H
#define TASK_H

// Define the return type for Task functions
typedef enum {
    TASK_SUCCESS,
    TASK_ERROR
} Task_Ret;

// Define the type for the task work callback function
typedef void (*TaskWorkCallback)(void*);

// Define the type for TaskState
typedef enum {
    TASK_READY,
    TASK_RUNNING,
    TASK_COMPLETED,
    TASK_ERROR_STATE // Add more states as needed
} TaskState;

// Define the type of State
typedef enum {
    WAIT,
    CALIBRATION,
    MODE_SWITCH,
    START_RACE,
    RUN_RACE,
    RACE_DONE,
} StateEnum;

// Define the Task structure
typedef struct Task {
    TaskWorkCallback workCallback; // Function to the task's work function
    TaskState state; // Current state of the task
    void* data; // Optional data associated with the task
} Task;

// Function prototype for initializing a task
Task_Ret Task_init(Task* task, TaskWorkCallback workCallback, TaskState state, void* data);

#endif // TASK_H
