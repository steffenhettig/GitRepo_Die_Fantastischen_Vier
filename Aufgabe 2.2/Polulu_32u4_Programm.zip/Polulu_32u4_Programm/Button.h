#ifndef BUTTON_H
#define BUTTON_H

// Define the Button ID type
typedef enum {
    BUTTON_1,
    BUTTON_2,
    BUTTON_3,
    // Add more button IDs as needed
} ButtonID;

// Define the Button state type
typedef enum {
    BUTTON_STATE_RELEASED,
    BUTTON_STATE_PRESSED
    // Add more button states as needed
} ButtonState;

// Function prototypes for Button
void Button_init(void);
ButtonState Button_getState(ButtonID buttonID);

#endif // BUTTON_H
