#ifndef MAINTASK_H
#define MAINTASK_H

#include "Scheduler.h" // Include the Scheduler header file to reference Scheduler types

// Define the return type for MainTask_init function
typedef enum {
    MAINTASK_SUCCESS,
    MAINTASK_ERROR
} MainTask_Ret;

// Function prototype for initializing the MainTask
MainTask_Ret MainTask_init(void);

#endif // MAINTASK_H
