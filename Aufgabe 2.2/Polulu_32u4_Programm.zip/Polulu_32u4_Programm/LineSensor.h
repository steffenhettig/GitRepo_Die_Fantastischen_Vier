#ifndef LINESENSOR_H
#define LINESENSOR_H

#include <stdbool.h> // Include for boolean type

// Define the LineSensorValues structure
typedef struct {
    // Define the variables to store sensor readings
    // Adjust the data types and number of variables as needed
    int sensor1Value;
    int sensor2Value;
    // Add more variables as needed for additional sensors
} LineSensorValues;

// Function prototypes for LineSensor
void LineSensor_init(void);
void LineSensor_startCalibration(void);
void LineSensor_stopCalibration(void);
bool LineSensor_getCalibrationState(void);
void LineSensor_read(LineSensorValues* values);
void LineSensor_enableEmitter(void);
void LineSensor_disableEmitter(void);

#endif // LINESENSOR_H
