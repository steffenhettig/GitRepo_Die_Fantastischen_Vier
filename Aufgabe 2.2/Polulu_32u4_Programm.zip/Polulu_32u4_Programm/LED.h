#ifndef LED_H
#define LED_H

// Define the LED enumeration
typedef enum {
    LED_1,
    LED_2,
    // Add more LEDs as needed
} Led_Led;

// Function prototypes for LED
void Led_init(void);
void Led_switchOn(Led_Led led);
void Led_switchOff(Led_Led led);

#endif // LED_H
