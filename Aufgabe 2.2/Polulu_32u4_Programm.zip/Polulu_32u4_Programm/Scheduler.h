#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "Task.h" // Include the Task header file to reference Task types

// Define the return type for Scheduler functions
typedef enum {
    SCHEDULER_SUCCESS,
    SCHEDULER_ERROR
} Scheduler_Ret;

// Function prototypes for Scheduler
Scheduler_Ret Scheduler_init(void);
void Scheduler_execute(void);
Scheduler_Ret Scheduler_addTask(Task* task);
Scheduler_Ret Scheduler_removeTask(Task* task);

#endif // SCHEDULER_H
