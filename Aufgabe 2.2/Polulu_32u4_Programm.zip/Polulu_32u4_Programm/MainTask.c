#include "MainTask.h"

// Implementation of MainTask_init function
MainTask_Ret MainTask_init(void) {
    // Register the MainTask with the Scheduler
    // This assumes that the Scheduler has been initialized elsewhere in the code
    Scheduler_Ret ret = Scheduler_addTask(&MainTask_init); // Register MainTask_init function with the Scheduler
    if (ret != SCHEDULER_SUCCESS) {
        // Handle error if registration fails
        return MAINTASK_ERROR;
    }
    return MAINTASK_SUCCESS;
}