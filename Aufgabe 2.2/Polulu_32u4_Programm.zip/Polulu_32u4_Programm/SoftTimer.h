#ifndef SOFTTIMER_H
#define SOFTTIMER_H

#include <stdint.h> // Include for standard integer types

// Define the return type for SoftTimer functions
typedef enum {
    SOFTTIMER_SUCCESS,
    SOFTTIMER_ERROR
} SoftTimer_Ret;

// Define the SoftTimer structure
typedef struct SoftTimer {
    uint16_t duration; // Duration of the timer in milliseconds
    uint16_t currentCount; // Current count of the timer
    // Add any other necessary fields here
} SoftTimer;

// Function prototypes for SoftTimer
void SoftTimer_init(SoftTimer* timer);
SoftTimer_Ret SoftTimer_start(SoftTimer* timer, uint16_t duration);
SoftTimer_Ret SoftTimer_stop(SoftTimer* timer);
void SoftTimer_update(SoftTimer* timer);
SoftTimer_Ret SoftTimer_restart(SoftTimer* timer);
uint16_t SoftTimer_get(SoftTimer* timer);

// Function prototypes for SoftTimerHandler
void SoftTimerHandler_init(void);
SoftTimer_Ret SoftTimerHandler_register(SoftTimer* timer);
SoftTimer_Ret SoftTimerHandler_unRegister(SoftTimer* timer);
void SoftTimerHandler_update(void);
uint64_t SoftTimer_getTimeStampMs(void);

#endif // SOFTTIMER_H
