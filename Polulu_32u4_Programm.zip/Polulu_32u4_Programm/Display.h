#ifndef DISPLAY_H
#define DISPLAY_H

#include <stdint.h> // Include for standard integer types

// Function prototypes for Display
void Display_init(void);
void Display_clear(void);
void Display_clearLine(void);
void Display_home(void);
void Display_gotoxy(uint8_t x, uint8_t y);
void Display_write(char* text, uint8_t length);
void Display_writeBar(uint8_t value);

#endif // DISPLAY_H
