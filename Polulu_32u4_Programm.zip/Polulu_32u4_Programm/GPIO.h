#ifndef GPIO_H
#define GPIO_H

#include <stdint.h> // Include for standard integer types

// Define the GPIO ID type
typedef enum {
    GPIO_ID_1,
    GPIO_ID_2,
    // Add more GPIO IDs as needed
} Gpio_ID;

// Define the GPIO state type
typedef enum {
    GPIO_STATE_LOW,
    GPIO_STATE_HIGH
    // Add more GPIO states as needed
} Gpio_State;

// Define the return type for GPIO functions
typedef enum {
    GPIO_SUCCESS,
    GPIO_ERROR
} Gpio_Ret;

// Function prototypes for GPIO
Gpio_Ret Gpio_init(void);
Gpio_Ret Gpio_write(Gpio_ID id, Gpio_State state);
Gpio_Ret Gpio_read(Gpio_ID id, Gpio_State* state);
Gpio_Ret Gpio_alloc(Gpio_ID id, uint8_t* pin);
Gpio_Ret Gpio_free(Gpio_ID id, uint8_t pin);

#endif // GPIO_H
