#ifndef DRIVECONTROL_H
#define DRIVECONTROL_H

#include <stdint.h> // Include for standard integer types

// Define the Motor ID enumeration
typedef enum {
    MOTOR_LEFT,
    MOTOR_RIGHT,
    // Add more motors as needed
} DriveControlMotorID;

// Define the direction enumeration
typedef enum {
    DIRECTION_FORWARD,
    DIRECTION_BACKWARD,
    // Add more directions as needed
} DriveControl_Direction;

// Function prototypes for DriveControl
void DriveControl_init(void);
void DriveControl_drive(DriveControlMotorID motorID, uint8_t speed, DriveControl_Direction direction);
int32_t DriveControl_getMileage(void);
void DriveControl_resetMileage(void);

#endif // DRIVECONTROL_H
