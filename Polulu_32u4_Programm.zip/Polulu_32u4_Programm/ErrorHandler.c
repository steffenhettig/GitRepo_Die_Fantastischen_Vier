#include "ErrorHandler.h"

// Define the function pointers for error and print callbacks
static ErrorCallback errorCallback = 0;
static PrintCallback printCallback = 0;

// Implementation of ErrorHandler_show function
void ErrorHandler_show(ErrorHandlerErrorCode errorCode) {
    // Handle showing the error code
    if (errorCallback != 0) {
        errorCallback(errorCode);
    }
}

// Implementation of ErrorHandler_halt function
void ErrorHandler_halt(ErrorHandlerErrorCode errorCode) {
    // Handle halting the system due to an error
    if (printCallback != 0) {
        printCallback("Error occurred. Halting system...");
    }
    // Implement halt logic here
}

// Implementation of ErrorHandler_setErrorCallback function
void ErrorHandler_setErrorCallback(ErrorCallback cb) {
    errorCallback = cb;
}

// Implementation of ErrorHandler_setPrintCallback function
void ErrorHandler_setPrintCallback(PrintCallback cb) {
    printCallback = cb;
}
