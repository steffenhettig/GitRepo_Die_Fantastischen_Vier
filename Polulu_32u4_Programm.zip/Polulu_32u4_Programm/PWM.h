#ifndef PWM_H
#define PWM_H

#include <stdint.h> // Include for standard integer types

// Define the PWM ID type
typedef enum {
    PWM_ID_1,
    PWM_ID_2,
    // Add more PWM IDs as needed
} PwmID;

// Function prototypes for PWM
void Pwm_init(void);
void Pwm_setDutyCycle(PwmID id, uint8_t dutyCycle);

#endif // PWM_H
