#ifndef BUZZER_H
#define BUZZER_H

// Define the Buzzer ID type
typedef enum {
    BUZZER_1,
    BUZZER_2,
    // Add more buzzer IDs as needed
} BuzzerID;

// Function prototypes for Buzzer
void Buzzer_init(void);
void Buzzer_beep(BuzzerID buzzerID);

#endif // BUZZER_H
