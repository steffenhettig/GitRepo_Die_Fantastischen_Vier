#ifndef TICKTIMER_H
#define TICKTIMER_H

#include <stdint.h> // Include for standard integer types

// Define the function pointer type for timer tick callback
typedef void (*TimerTickCallback)(void);

// Function prototypes for TickTimer
void TickTimer_init(void);
void TickTimer_setCallback(TimerTickCallback callback);
uint64_t TickTimer_get(void);
void TickTimer_delay(uint8_t milliseconds);

#endif // TICKTIMER_H
