#ifndef IRQ_H
#define IRQ_H

// Define the IRQ ID type
typedef enum {
    IRQ_ID_1,
    IRQ_ID_2,
    // Add more IRQ IDs as needed
} IrqID;

// Define the function pointer type for IRQ callback
typedef void (*IrqCallback)(void);

// Function prototypes for IRQ
void Irq_init(void);
void Irq_enable(IrqID irqID);
void Irq_disable(IrqID irqID);
void Irq_setCallback(IrqID irqID, IrqCallback callback);

#endif // IRQ_H
