#ifndef ERRORHANDLER_H
#define ERRORHANDLER_H

// Define the error codes
typedef enum {
    ERROR_CODE_1,
    ERROR_CODE_2,
    // Add more error codes as needed
} ErrorHandlerErrorCode;

// Define the function pointer types for error and print callbacks
typedef void (*ErrorCallback)(ErrorHandlerErrorCode);
typedef void (*PrintCallback)(const char*);

// Function prototypes for ErrorHandler
void ErrorHandler_show(ErrorHandlerErrorCode errorCode);
void ErrorHandler_halt(ErrorHandlerErrorCode errorCode);
void ErrorHandler_setErrorCallback(ErrorCallback errorCallback);
void ErrorHandler_setPrintCallback(PrintCallback printCallback);

#endif // ERRORHANDLER_H
